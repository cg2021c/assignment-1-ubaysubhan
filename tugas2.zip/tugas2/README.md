[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-f059dc9a6f8d3a56e377f745f24479a46679e63a5d9fe6f495e02850cd0d8118.svg)](https://classroom.github.com/online_ide?assignment_repo_id=5696030&assignment_repo_type=AssignmentRepo)

OBJECT = Clock

top right, top left, top rear, top front

<img src="https://user-images.githubusercontent.com/77099292/134208280-9fc49f2a-ca0b-4624-8e17-c7ec6c48ee14.jpg" width="250" height="250">

<img src="https://user-images.githubusercontent.com/77099292/134208304-8026e173-7751-47e0-b64c-eb04c5ea4147.jpg" width="250" height="250">

<img src="https://user-images.githubusercontent.com/77099292/134208314-18bc9ccf-c63d-47ba-bd3d-6915e9a11614.jpg" width="250" height="250">

<img src="https://user-images.githubusercontent.com/77099292/134208319-87bfb8a7-6b89-4233-a695-3ef531c2e5b9.jpg" width="250" height="250">




